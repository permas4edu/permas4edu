import os, sys
import numpy as np
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
#mpl.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
from scipy import interpolate
csv = sys.argv[1]
df = pd.read_csv(csv,delimiter=';')

fig = plt.figure('Nodal lines')
ax = fig.add_subplot(111)

x = df['Coor_Y1'].values
for i,column in enumerate(df.columns[1:6]):
    y = df[column].values

    tck = interpolate.splrep(x, y, s=0)
    roots = interpolate.sproot(tck,mest=10)
    print (i,len(roots))
    if len(roots) > 0:
        ax.plot(x,y,label='%s NDIA=%i' %(column,len(roots)/2))
ax.legend(shadow=True).set_draggable(True)
ax.set_xlabel(r'Angle $\varphi$ [$^\circ$]')
ax.grid()
plt.savefig('nodal_lines')
plt.show()
