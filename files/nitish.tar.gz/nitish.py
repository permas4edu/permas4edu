import os, sys
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
mpl.rcParams['savefig.directory'] = os.getcwd()

dhis=pd.read_csv('sampling_xdhis.csv',delimiter=';')
srhis=pd.read_csv('sampling_srhis.csv',delimiter=';')
fig = plt.figure('')
ax = fig.add_subplot(111)
ax.grid()
ax.plot(55+dhis['DV_1'],srhis['F_1'],label=r'$%s$' %srhis.keys()[1].replace('F','f'))
ax.plot(55+dhis['DV_1'],srhis['F_2'],label=r'$%s$' %srhis.keys()[2].replace('F','f'))
ax.plot(55+dhis['DV_1'],srhis['F_3'],label=r'$%s$' %srhis.keys()[3].replace('F','f'))
ax.plot(55+dhis['DV_1'],srhis['F_4'],label=r'$%s$' %srhis.keys()[4].replace('F','f'))
ax.set_xlabel(r'Outer radius $r$ [mm]')
ax.legend(shadow=True).set_draggable(True)
ax.set_ylabel(r'Natural frequency $f$ [Hz]')
plt.tight_layout()
plt.show()
