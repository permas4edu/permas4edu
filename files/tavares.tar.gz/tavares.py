import os, sys
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

csv1 = sys.argv[1]
csv2 = sys.argv[2]

data1 = np.loadtxt('sampling_xdhis.csv',delimiter=';',skiprows=1)
data2 = np.loadtxt('sampling_srhis.csv',delimiter=';',skiprows=1)

fig = plt.figure('Natural frequencies')
ax = fig.add_subplot(111)

ax.plot(data1[:,1],data2[:,1],label=r'$f_1$')
ax.plot(data1[:,1],data2[:,2],label=r'$f_2$')
ax.plot(data1[:,1],data2[:,3],label=r'$f_3$')
ax.set_xlabel(r'Thickness of damage zones $t$ [mm]')
ax.grid()
ax.set_ylabel('Natural frequency $f_i$ [Hz]')
ax.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
