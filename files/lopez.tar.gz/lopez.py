import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import numpy as np

csv1 = np.loadtxt('step_1_bas.csv',delimiter=';',skiprows=1)
csv2 = np.loadtxt('step_2_mod.csv',delimiter=';',skiprows=1)

fig = plt.figure('Cantilever beam')
ax = fig.add_subplot(111)
ax.plot(csv1[:,0],csv1[:,1]/csv1[:,1].max(),label=r'$f_1$')
ax.plot(csv1[:,0],csv1[:,2]/csv1[:,2].max(),label=r'$f_2$')
ax.plot(csv1[:,0],csv1[:,3]/csv1[:,3].max(),label=r'$f_3$')

ax.plot(csv2[:,0],csv2[:,1]/csv2[:,1].max(),'-.',label=r'$f_1$')
ax.plot(csv2[:,0],csv2[:,2]/csv2[:,2].max(),'-.',label=r'$f_2$')
ax.plot(csv2[:,0],csv2[:,3]/csv2[:,3].max(),'-.',label=r'$f_3$')
ax.set_xlabel(r'$L$ [m]')
ax.set_ylabel('Mode shape')
ax.set_xticks(np.linspace(0.,2.,11))
ax.set_yticks(np.linspace(-0.8,1.,10))
ax.grid()
ax.legend(shadow=True).set_draggable(True)
plt.show()
