import numpy as np
import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd

csv1 = sys.argv[1]
csv2 = sys.argv[2]

data1 = pd.read_csv(csv1,delimiter=';')
data2 = pd.read_csv(csv2,delimiter=';')

fig = plt.figure('Frequency Response')
ax = fig.add_subplot(111)
ax.semilogy(2*np.pi*data1['Frequency'],data1['N2,u'],label='Oscillator chain')
ax.semilogy(2*np.pi*data2['Frequency'],data2['N2,u'],label='Combined system')
ax.grid()
ax.set_xlabel('Frequency $\Omega$ [rad]')
ax.set_ylabel('Amplitude')
ax.set_xticks(np.linspace(0.,9.,10))
ax.legend(shadow=True).set_draggable(True)
plt.show()
