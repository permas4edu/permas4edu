import numpy as np
import pandas as pd
import matplotlib as mpl
import os
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import mplcursors
df = pd.read_csv('sampling_srhis.csv',delimiter=';')
l = df.values[0,1:]
m =l.shape
fig = plt.figure('Eigenvalues')
ax = fig.add_subplot(111,aspect='equal')
ax.plot(l,np.zeros(m),'o')

r = 0.4
phi = np.linspace(0.,2*np.pi,100)
x = 2+r*np.cos(phi)
y = r*np.sin(phi)
ax.plot(x,y,'-')
ax.set_title('Click on the points inside the circle')
mplcursors.cursor(ax,multiple=True).connect(
    "add", lambda sel: sel.annotation.set_text(r'$\lambda=%.5f [rad^2/s^2]$'%l[sel.index]))
plt.show()
print (l)
