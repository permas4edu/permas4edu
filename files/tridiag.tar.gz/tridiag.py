from numpy.random import default_rng
rng = default_rng()
vals = rng.normal(loc=1.0, scale=1.E-7, size=64)
ofile = open('uniform.csv','w')
for i, val in enumerate(vals):
    ofile.write('GD_%i %.12e\n' %(i+1,val))
ofile.close()    
