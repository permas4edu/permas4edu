import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
df1 = pd.read_csv('hbm_asc_xy_resp.csv',delimiter=';')

fig = plt.figure('HBM',figsize=(8,12))
ax1 = fig.add_subplot(111)
ax1.plot(2*np.pi*df1['Frequency'],df1['H1-N101,u'],label='H1 N101 ascending')
ax1.grid()
ax1.set_xlabel(r'Frequency $\Omega$ [rad/s]')
ax1.set_ylabel(r'Peak Amplitude $A_1$')
ax1.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
