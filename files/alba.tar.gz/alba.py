import os, sys
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

csv1 = sys.argv[1]
data = np.loadtxt(csv1,delimiter=';',skiprows=1)

fig = plt.figure('Cantilever',figsize=(4,10))
ax = fig.add_subplot(111)
ax.plot(data[:,1]/data[:,1].max(),data[:,0],label=r'$f_1$')
ax.plot(data[:,2]/data[:,2].max(),data[:,0],label=r'$f_2$')
ax.plot(data[:,3]/data[:,3].max(),data[:,0],label=r'$f_3$')

ax.set_ylabel(r'Height $H$ [m]')
ax.set_xlabel('Mode shape')
ax.grid()
ax.legend(shadow=True).set_draggable(True)
plt.show()
