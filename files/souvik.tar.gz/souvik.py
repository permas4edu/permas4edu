import os, sys
import numpy as np
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
#mpl.use('Agg')
import matplotlib.pyplot as plt

import pandas
data=pandas.read_csv('sampling_srhis.csv',delimiter=';')
m,n= data.shape

fig = plt.figure('Random eigenvalues')
ax = fig.add_subplot(111)
ax.set_title('Number of samples: %i'%m)
ax.plot(2*np.pi*data['F_1'],2*np.pi*data['F_2'],'o',label=r'$(\omega_1,\omega_2)$')
ax.plot(2*np.pi*data['F_1'],2*np.pi*data['F_3'],'o',label=r'$(\omega_1,\omega_3)$')
ax.plot(2*np.pi*data['F_2'],2*np.pi*data['F_3'],'o',label=r'$(\omega_2,\omega_3)$')
ax.grid()
ax.set_xlabel(r'$\omega_j$ [rad/s]')
ax.set_ylabel(r'$\omega_k$ [rad/s]')
ax.legend(loc=0,shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
