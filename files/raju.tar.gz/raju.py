import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
#mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


csv1 = sys.argv[1]
csv2 = sys.argv[2]
data1 = np.loadtxt(csv1,delimiter=';',skiprows=1)
data2 = np.loadtxt(csv2,delimiter=';',skiprows=1)

fig = plt.figure('FRF')
ax = fig.add_subplot(111)
ax.plot(data1[:,0],20*np.log10(np.sqrt(0.5)*data1[:,1]/20.e-6),lw=2,label='modal method PERMAS')
ax.plot(data2[:,0],20*np.log10(np.sqrt(0.5)*data2[:,1]/20.e-6),lw=2,label='direct method PERMAS')
ax.minorticks_on()
ax.grid()
ax.set_xlabel('Frequency $f$ [Hz]')
ax.set_ylabel('Pressure $p$ [dB]')
ax.legend(shadow=True).set_draggable(True)
plt.tight_layout()
#plt.savefig('frf')
plt.show()
 
