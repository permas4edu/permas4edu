import os, sys
import pandas as pd
import numpy as np
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
mpl.use('Agg')
import matplotlib.pyplot as plt
csv = sys.argv[1]

df = pd.read_csv(csv,delimiter=';')
fig = plt.figure('Response',figsize=(12,8))
ax = fig.add_subplot(111)
ax.grid('on')
ax.set_xlabel(r'Time $t$ [s]')
ax.set_ylabel(r'Displacement $u(x=\ell,t)$')
ax.plot(df['Time'],df['N256,u'])
plt.tight_layout()
plt.savefig('response.png',dpi=80)
#plt.show()
