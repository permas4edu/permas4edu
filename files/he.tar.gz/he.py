import os, sys
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
mpl.rcParams['savefig.directory'] = os.getcwd()

csv = sys.argv[1]

data = np.loadtxt(csv,skiprows=1,delimiter=';')

plt.subplot(2,2,1)
plt.plot(data[:,0],data[:,1],label=r'$f_1$')
plt.grid()
plt.xlabel(r'Position $x$ [m]')
plt.ylabel(r'Natural frequency $f$ [Hz]')
plt.legend(loc=0,shadow=True)
plt.subplot(2,2,2)
plt.plot(data[:,0],data[:,2],label=r'$f_2$')
plt.grid()
plt.xlabel('Position $x$ [m]')
plt.ylabel(r'Natural frequency $f$ [Hz]')
plt.legend(loc=0,shadow=True)
plt.subplot(2,2,3)
plt.plot(data[:,0],data[:,3],label=r'$f_3$')
plt.grid()
plt.xlabel('Position $x$ [m]')
plt.ylabel(r'Natural frequency $f$ [Hz]')
plt.legend(loc=0,shadow=True)
plt.subplot(2,2,4)
plt.plot(data[:,0],data[:,4],label=r'$f_4$')
plt.grid()
plt.xlabel('Position $x$ [m]')
plt.ylabel(r'Natural frequency $f$ [Hz]')
plt.legend(loc=0,shadow=True)
plt.tight_layout()
plt.show()
