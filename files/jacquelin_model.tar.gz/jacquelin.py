import os, sys
import numpy as np
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd

def f(x):
    return x

df = pd.read_csv('campbell_rsfrq.csv',delimiter=';')

fig = plt.figure('Campbell')
ax = fig.add_subplot(111)
ax.plot(df['Rot.Freq.'],df['Mode 1'],label='BW1')
ax.plot(df['Rot.Freq.'],df['Mode 3'],label='FW1')
ax.plot(df['Rot.Freq.'],df['Mode 5'],label='BW2')
ax.plot(df['Rot.Freq.'],df['Mode 7'],label='FW2')
ax.plot(df['Rot.Freq.'],f(df['Rot.Freq.']),'-.')
ax.set_xlim(0.,150.)
ax.set_ylim(0.,150.)
ax.set_xticks(np.linspace(0.,150.,4))
ax.set_yticks(np.linspace(0.,150.,4))
ax.set_xlabel('Rotational speed [Hz]')
ax.set_ylabel('Frequency')
ax.grid()
ax.legend(shadow=True).set_draggable(True)
plt.show()
