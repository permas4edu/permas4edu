import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


csv = sys.argv[1]
data = np.loadtxt(csv,delimiter=';',skiprows=1)

fig = plt.figure('DEFLECTION',figsize=(4,8))
ax = fig.add_subplot(111)
ax.plot(data[:,1],data[:,0],lw=2,label='PERMAS')
ax.grid()
ax.set_xlabel('deflection $v$ [m]')
ax.set_ylabel('Height $h$ [m]')
ax.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.savefig('deflection')
#plt.show()
