import os, sys
import glob
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
colors = plt.rcParams["axes.prop_cycle"]()

fig, axs = plt.subplots(3, 2, figsize=(8, 12), num='HBM')
fig.suptitle("Harmonic Balance Method")
csvs = glob.glob('hbm_xy*.csv')
csvs.sort()
label=[0.005, 0.09, 0.098, 0.11, 0.15, 0.19] # Load amplitudes
for i, csv in enumerate(csvs):
    print ('Processing %s'%csv)
    df = pd.read_csv(csv,delimiter=';')
    # Get the next color from the cycler
    c = next(colors)["color"]    
    if i == 0:
        axs[0, 0].plot(2*np.pi*df['Frequency'],df['H1-N101,u'],color=c,label=r'$F=$%.3f [N]'%label[i])
        axs[0, 0].grid()
        axs[0, 0].legend(shadow=True).set_draggable(True)
    elif i == 1:
        axs[0, 1].plot(2*np.pi*df['Frequency'],df['H1-N101,u'],color=c,label=r'$F=$%.3f [N]'%label[i])
        axs[0, 1].grid()
        axs[0, 1].legend(shadow=True).set_draggable(True)
        
    elif i == 2:
        axs[1, 0].plot(2*np.pi*df['Frequency'],df['H1-N101,u'],color=c,label=r'$F=$%.3f [N]'%label[i])
        axs[1, 0].grid()
        axs[1, 0].legend(shadow=True).set_draggable(True)
       
    elif i == 3:
        axs[1, 1].plot(2*np.pi*df['Frequency'],df['H1-N101,u'],color=c,label=r'$F=$%.3f [N]'%label[i])
        axs[1, 1].grid()
        axs[1, 1].legend(shadow=True).set_draggable(True)
        
    elif i == 4:
        axs[2, 0].plot(2*np.pi*df['Frequency'],df['H1-N101,u'],color=c,label=r'$F=$%.3f [N]'%label[i])
        axs[2, 0].grid()
        axs[2, 0].legend(shadow=True).set_draggable(True)
        
    elif i == 5:
        axs[2, 1].plot(2*np.pi*df['Frequency'],df['H1-N101,u'],color=c,label=r'$F=$%.3f [N]'%label[i])        
        axs[2, 1].grid()
        axs[2, 1].legend(shadow=True).set_draggable(True)
for ax in axs.flat:
    ax.set(xlabel=r'Frequency $\Omega$ [rad/s]', ylabel='Displacement $x_1$ [m]')
    ax.set_xlim(0.8,2.8)
    ax.set_xticks(np.linspace(0.8,2.8,11))
# Hide x labels and tick labels for top plots and y ticks for right plots.
#for ax in axs.flat:
#    ax.label_outer()    
plt.tight_layout()
plt.show()
