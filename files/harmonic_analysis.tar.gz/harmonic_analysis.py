import numpy as np
import os, sys
import matplotlib as mpl
import matplotlib.pyplot as plt
import xlsxwriter
mpl.rcParams['savefig.directory'] = os.getcwd()

csv1 = sys.argv[1]
csv2 = sys.argv[2]

fig1 = plt.figure('Harmonic analysis I')
ax1  = fig1.add_subplot(211)
ax2  = fig1.add_subplot(212,sharex=ax1)

data1 = np.genfromtxt(csv1,delimiter=';',names=True)
data2 = np.genfromtxt(csv2,delimiter=';',names=True)
header = data1.dtype.names
ax1.plot(data1[header[0]],data1[header[1]],'-',label=header[1])
ax1.set_xlabel(r'Frequency $f$ [Hz]')
if '_amp' in csv1:
    ax1.set_ylabel(r'Amplitude $v$ [m]')
if '_vamp' in csv1:
    ax1.set_ylabel(r'Amplitude $v$ [m/s]')
if '_aamp' in csv1:
    ax1.set_ylabel(r'Amplitude $v$ [m/s$^2$]')
ax2.plot(data2[header[0]],np.rad2deg(data2[header[1]]),'-',label=header[1])
ax2.set_xlabel(r'Frequency $f$ [Hz]')
ax2.set_ylabel(r'Phase $\varphi$ [$ ^{\circ}$]')
ax1.legend(loc=0,shadow=True)
ax2.legend(loc=0,shadow=True)
ax1.grid()
ax2.grid()
plt.tight_layout()
plt.savefig(csv1[:-4]+'_I')
fig2 = plt.figure('Harmonic analysis II')
ax3  = fig2.add_subplot(111)
ax3.semilogy(data1[header[0]],data1[header[1]],'-',label=header[1])
ax3.set_xlabel(r'Frequency $f$ [Hz]')
if '_amp' in csv1:
    ax3.set_ylabel(r'Amplitude [dB] ref. [1m]')
if '_vamp' in csv1:
    ax3.set_ylabel(r'Amplitude [dB] ref. [1m/s]')
if '_aamp' in csv1:
    ax3.set_ylabel(r'Amplitude [dB] ref. [1m/s$^2$]')    
ax3.grid()
plt.tight_layout()
plt.savefig(csv1[:-4]+'_II')

workbook = xlsxwriter.Workbook(csv1[:-4]+'.xlsx')
worksheet = workbook.add_worksheet('Modal Analysis')
workbook.set_properties({
    'title':    'FRF',
    'subject':  'Harmonic analysis',
    'author':   'Nils Wagner',
    'manager':  '',
    'company':  'Intes GmbH',
    'category': 'Example spreadsheet',
    'keywords': 'PERMAS, Vibration Analysis, Frequency Response, Modal Analysis',
    'comments': 'Created with pyINTES',
    'status':   'New',
})
worksheet.set_column('A:A', 13)
worksheet.set_column('B:B', 13)
worksheet.set_column('C:C', 13)
worksheet.write(0,0,'Frequency')
worksheet.write(0,1,'Amplitude')
worksheet.write(0,2,'Phase')
worksheet.write_column('A2',data1[header[0]])
worksheet.write_column('B2',data1[header[1]])
worksheet.write_column('C2',np.rad2deg(data2[header[1]]))

worksheet.insert_image('E2',csv1[:-4]+'_I.png' , {'x_scale': 1.0, 'y_scale': 1.0})
worksheet.insert_image('E30',csv1[:-4]+'_II.png' , {'x_scale': 1.0, 'y_scale': 1.0})
workbook.close()
#plt.show()
