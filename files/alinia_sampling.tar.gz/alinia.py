import os, sys
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt

data = pd.read_csv('sampling_srhis.csv',delimiter=';')
fig = plt.figure('Loadscale Factor')
ax = fig.add_subplot(111)
ax.plot((100+data['DV_1'])/1000.,data['LSF_1'],label=r'$\lambda_1$')
ax.grid()
ax.legend(shadow=True).set_draggable(True)
ax.set_xlabel(r'$\frac{b}{d}$')
ax.set_ylabel('Loadscale factor')
plt.savefig('load_scale_factor')
plt.show()
