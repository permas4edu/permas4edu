import os, sys
import pandas as pd
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import mplcursors
df1 = pd.read_csv('tracking_srhis.csv',delimiter=';')
df2 = pd.read_csv('objective_xohis.csv',delimiter=';')
fig = plt.figure('Optimization')
ax1 = fig.add_subplot(211)
ax2 = fig.add_subplot(212,sharex=ax1)
ax1.plot(df1['Loop'],df1['F_1'],'-o',label=r'$f_1$')
ax1.plot(df1['Loop'],df1['F_2'],'-o',label=r'$f_2$')
ax1.plot(df1['Loop'],df1['F_3'],'-o',label=r'$f_3$')
ax1.set_xlabel('Loop')
ax1.set_ylabel(r'Natural frequencies $f_i$ [Hz]')
ax1.grid()
ax1.legend(shadow=True).set_draggable(True)
ax2.plot(df2['Loop Number'],df2['WEIG_DMODL'],'-o',label=r'$m$')
ax2.set_xlabel('Loop')
ax2.set_ylabel(r'Mass $m$ [kg]')
ax2.grid()
ax2.legend(shadow=True).set_draggable(True)
mplcursors.cursor(ax1,multiple=True)
mplcursors.cursor(ax2,multiple=True)
plt.tight_layout()
plt.show()
