import os, sys
import glob
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


fig = plt.figure('HBM',figsize=(8,12))
ax1 = fig.add_subplot(111)
#ax2 = fig.add_subplot(212,sharex=ax1)
csvs = glob.glob('hbm_xy*.csv')
csvs.sort()
label=[0.001,0.025,0.05,0.075,0.1] # Load amplitudes
for i, csv in enumerate(csvs):
    print ('Processing %s'%csv)
    df = pd.read_csv(csv,delimiter=';')
    ax1.plot(2*np.pi*df['Frequency'],df['H1-N101,u']/float(label[i]),label=r'$F=$%.3f [N]'%label[i])
ax1.grid()
ax1.set_xlim(0.4,1.9)
ax1.set_xticks(np.linspace(0.4,1.8,8))
ax1.set_yticks(np.linspace(0.0,10.0,5))
ax1.set_ylabel(r' $\frac{x_1}{f_0}$')
ax1.set_xlabel(r'Excitation frequency $\Omega$ [rad/s]')
ax1.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
