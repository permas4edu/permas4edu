import numpy as np

L = 1.0
nele = 200
A_0 = 0.001
gamma = 1.
k_0 = gamma/L
#k_0 = 0. # constant cross section
r = 1.0
gamma_1 = 1.0
p = gamma_1/L
Young = 2.1E11
Poisson = 0.3
density = 7.85E3
# Equation 3.15
f = (np.arange(0,10)*2+1)*np.pi*np.sqrt(Young/density)/(4*np.pi*L) 
print ('First 10 Natural frequencies')
ofile = open('natural_frequencies.txt','w')
ofile.write('Equation 3.15\n')
ofile.write('\n')
ofile.write('     Row   Frequency \n')
np.savetxt(ofile, np.c_[np.arange(1,11),f], fmt='%8i %.5e')
ofile.close()

def A(x,case=2):
    if case == 1:
        return A_0*np.exp(-k_0*x)
    elif case == 2:
        return A_0
    elif case == 3:
        return A_0*(np.sinh(p*x+r))**2
    elif case == 4:
        return A_0*(np.cosh(p*x+r))**2
    elif case == 5:
        return A_0*(np.exp(np.sqrt(2*k)*x)+1)**2*np.exp(-np.sqrt(2*k)*x)
    
x = np.linspace(0.,L,nele+1) # Coordinates
ofile = open('pala.dat','w')
ofile.write('$ENTER COMPONENT NAME = DFLT_COMP\n')
ofile.write('    $SITUATION NAME = STEP_1\n')
ofile.write('        DFLT_COMP SYSTEM = S_STEP_1 CONSTRAINTS = C_STEP_1\n')
ofile.write('    $END SITUATION\n')
ofile.write('!\n') 
ofile.write('    $STRUCTURE\n')
ofile.write('    $COOR\n')
for i in range(nele+1):
    ofile.write('  %3i %.5e 0.0 0.0\n' %(i+1,x[i]))
ofile.write('!\n')    
ofile.write('    $ELEMENT TYPE = FLA2\n')
for i in range(nele):
    ofile.write('  %3i %3i %3i\n' %(i+1,i+1,i+2))
ofile.write('    $END STRUCTURE\n')
ofile.write('!\n')
ofile.write('    $CONSTRAINTS NAME = C_STEP_1\n')
ofile.write('        $SUPPRESS DOFS = 1\n')
ofile.write('            1\n')
ofile.write('        $SUPPRESS DOFS = 2, 3\n')
ofile.write('            NODEDISP\n')
ofile.write('    $END CONSTRAINTS\n')
ofile.write('!\n') 
ofile.write('    $SYSTEM NAME = S_STEP_1\n')
ofile.write('        $ELPROP\n')
for i in range(nele):
    ofile.write('        %3i GEODAT = GD_%i MATERIAL = MAT_1\n' %(i+1,i+1))
ofile.write('!\n')
ofile.write('        $GEODAT FLANGE CONT = SECTION\n')
for i in range(nele):
    ofile.write('       GD_%i %.8e %.8e\n' %(i+1,A(x[i]),A(x[i+1])))
ofile.write('!\n')    
ofile.write('    $END SYSTEM\n')
ofile.write('!\n') 
ofile.write('$EXIT COMPONENT\n')
ofile.write('$ENTER MATERIAL\n')
ofile.write('    $MATERIAL NAME = MAT_1\n')
ofile.write('        $ELASTIC GENERAL\n')
ofile.write('            %.1e %.3f\n' %(Young,Poisson))
ofile.write('        $DENSITY\n')
ofile.write('            %.3e\n' %density)
ofile.write('$EXIT MATERIAL\n')
ofile.write('$FIN\n')
ofile.close()

