import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
#mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

csv = sys.argv[1]
data = np.loadtxt(csv,delimiter=';',skiprows=1)
df = pd.read_csv(csv,index_col=None,delimiter=';')
header = list(df.columns.values)

fig, axs = plt.subplots(2, 3,figsize=(7,9))
axs[0,0].set_title(header[1])
axs[0,0].plot(data[:,1],data[:,0],lw=2,label='PERMAS')
axs[0,0].grid()
axs[0,0].set_xlabel('Mode shape $u$')
axs[0,0].set_ylabel('Height $h$')
axs[0,0].legend(shadow=True).set_draggable(True)
#
axs[0,1].set_title(header[2])
axs[0,1].plot(data[:,2],data[:,0],lw=2,label='PERMAS')
axs[0,1].grid()
axs[0,1].set_xlabel('Mode shape $u$')
axs[0,1].set_ylabel('Height $h$')
axs[0,1].legend(shadow=True).set_draggable(True)
#
axs[0,2].set_title(header[3])
axs[0,2].plot(data[:,3],data[:,0],lw=2,label='PERMAS')
axs[0,2].grid()
axs[0,2].set_xlabel('Mode shape $u$')
axs[0,2].set_ylabel('Height $h$')
axs[0,2].legend(shadow=True).set_draggable(True)
#
axs[1,0].set_title(header[4])
axs[1,0].plot(data[:,4],data[:,0],lw=2,label='PERMAS')
axs[1,0].grid()
axs[1,0].set_xlabel('Mode shape $u$')
axs[1,0].set_ylabel('Height $h$')
axs[1,0].legend(shadow=True).set_draggable(True)
#
axs[1,1].set_title(header[5])
axs[1,1].plot(data[:,5],data[:,0],lw=2,label='PERMAS')
axs[1,1].grid()
axs[1,1].set_xlabel('Mode shape $u$')
axs[1,1].set_ylabel('Height $h$')
axs[1,1].legend(shadow=True).set_draggable(True)
#
axs[1,2].set_title(header[6])
axs[1,2].plot(data[:,6],data[:,0],lw=2,label='PERMAS')
axs[1,2].grid()
axs[1,2].set_xlabel('Mode shape $u$')
axs[1,2].set_ylabel('Height $h$')
axs[1,2].legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
