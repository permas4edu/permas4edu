import os
import glob
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import matplotlib.cm as cmx
Reds = cm = plt.get_cmap('Reds')
cNorm  = colors.Normalize(vmin=0.0, vmax=8000.)
scalarMap = cmx.ScalarMappable(norm=cNorm, cmap=Reds)

csvs = glob.glob('static_*.csv')
csvs.sort()
label=pd.read_csv('sampling_srhis.csv',delimiter=';')

fig = plt.figure('Linear characteristics')
ax = fig.add_subplot(111)
for i, csv in enumerate(csvs):
    colorVal = scalarMap.to_rgba(np.round(label['BSV_1'][i]*60/(2*np.pi),1))
    df = pd.read_csv(csv,delimiter=';')
    ax.plot(1.E-3*df['Coor_X'],1.E-3*df['LPAT_999_u'],'-',color=colorVal,label=r'$\Omega=$%.1f [rpm]'%np.round(label['BSV_1'][i]*60/(2*np.pi),1))
ax.set_xlabel(r'$x$ [m]')
ax.set_ylabel(r' Longitudinal Amp. $u$ [m]')
ax.grid()
ax.ticklabel_format(style='sci', axis='y', scilimits=(0,3))
ax.set_xticks(np.linspace(0.1,1.1,3))
ax.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.savefig('rotating_cantilever_beam.png')
#plt.show()
