import os, sys, re
import gzip
from scipy.sparse import coo_matrix
from scipy.io import mmwrite, savemat
import matplotlib as mpl
mpl.use('Agg')
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pylab as plt
import matplotlib.cm as cm
import numpy as np
from scipy.linalg import eig, eigh, cho_solve, cho_factor

from numpy.linalg import cond
from scipy.sparse.linalg import eigs, eigsh

import warnings
warnings.simplefilter("ignore")
#
# pyINTES generalized.py  matrices.mtl
#
inp = sys.argv[1]


if inp.endswith('gz'):
    ifile = gzip.open(inp,'r')
else:    
    ifile = open(inp,'r')
print
print ('Processing %s' %inp)
print
while 1:

    line = ifile.readline()
    if not line : break

    if re.search('\$DATAOBJECT',line):
        liste = line.split()
        matname = liste[4]
        print (matname)
        col = []
        row = []
        val = []
        while 1:
            line = ifile.readline()
            if not line: break
            if re.search('$EXIT COMPONENT',line): break
            if line.startswith('%!'):
                print
                print ('End of data object')
                print
                break
            
            if re.search('ROWDIM',line):
                liste = line.split()
                rowdim = int(liste[3])
                coldim = int(liste[6])
                print (rowdim, coldim)
        
            if re.search('MATTYPE',line):
                liste = line.split()
                mattype = liste[6]
                if mattype == 'PS':
                    print ('Packed symmetric')
                elif mattype =='R':
                    print ('Rectangular')
                elif mattype =='D':
                    print ('Diagonal')
                else:
                    print ('Unknown matrix format')
            
            if re.search('BLOCKFORM',line):
                if re.search('FORMAT = R',line):
                    typ = 'R'
                elif re.search('FORMAT = PS',line):
                    typ = 'PS'
            
            liste = line.split()
            if len(liste) == 3:
                col.append(int(liste[0])-1)
                row.append(int(liste[1])-1)
                val.append(float(liste[2].replace('D','E')))
#
#       fill lower triangular 
#
                if mattype == 'PS':
                    if col[-1] != row[-1]:
                        col.append(int(liste[1])-1)
                        row.append(int(liste[0])-1)
                        val.append(float(liste[2].replace('D','E')))          
            
            
        if matname =='BMLL':
            BMLL = coo_matrix((val,(row,col)),shape=(rowdim,coldim))
        elif matname =='BKLL':
            BKLL = coo_matrix((val,(row,col)),shape=(rowdim,coldim))
        else:
            print ('Unknown matrix name %s' %matname)

ifile.close()

try:
    mmwrite('BMLL',BMLL)
    savemat('BMLL.mat',mdict={'BMLL': BMLL},format='5')
    fig1 = plt.figure(1)
    ax1  = fig1.add_subplot(211)
#   ax1.spy(BMLL)
    im1=ax1.imshow(BMLL.todense(),interpolation='none',cmap='coolwarm')
    ax1.set_title(r'$M$')
except:
    pass
try:
    
    mmwrite('BKLL',BKLL)
    savemat('BKLL.mat',mdict={'BKLL': BKLL},format='5')
    fig1 = plt.figure(1)
    ax2  = fig1.add_subplot(212)
#   ax2.spy(BKLL)
    im2=ax2.imshow(BKLL.todense(),interpolation='none',cmap='coolwarm')
    ax2.set_title(r'$K$')
  
except:
    pass
plt.colorbar(im1,ax=ax1)
plt.colorbar(im2,ax=ax2)
plt.tight_layout()
plt.savefig('matrices')
#plt.show()
try:
    w,vr=eigsh(BKLL,6, BMLL,which='SM')
except:
    w,vr=eigs(BKLL,6, BMLL,which='SM') 
    print ('eigsh failure')
#w,vr = eigh(BKLL.todense(), BMLL.todense())
f=np.sort(np.sqrt(w.real)/np.pi/2)
ofile = open('rvaltab.res','a')
ofile.write('\n')
ofile.write('Results by SciPy\n')
ofile.write('\n')
np.savetxt(ofile,f[:10],fmt='%.5e')
ofile.write('\n')
ofile.close()

