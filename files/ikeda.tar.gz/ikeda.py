import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
df = pd.read_csv('hbm_xy_resp.csv',delimiter=';')

fig = plt.figure('HBM',figsize=(8,12))
ax1 = fig.add_subplot(311)
ax2 = fig.add_subplot(312,sharex=ax1)
ax3 = fig.add_subplot(313,sharex=ax1)
ax1.plot(2*np.pi*df['Frequency'],df['H1-N1,u'],label=df.keys()[3+1])
ax2.plot(2*np.pi*df['Frequency'],df['H1-N2,u'],label=df.keys()[3+2])
ax3.plot(2*np.pi*df['Frequency'],df['H1-N3,u'],label=df.keys()[3+3])
ax1.grid()
ax2.grid()
ax3.grid()
ax3.set_xlabel(r'Frequency $\Omega$ [rad/s]')
ax1.set_xlim(0.9,1.2)
ax1.set_ylabel(r'Magnitude $A_1$')
ax2.set_ylabel(r'Magnitude $A_2$')
ax3.set_ylabel(r'Magnitude $A_3$')
ax1.legend(shadow=True).set_draggable(True)
ax2.legend(shadow=True).set_draggable(True)
ax3.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
