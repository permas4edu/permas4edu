import os, sys
import matplotlib as mpl
import matplotlib.pyplot as plt
mpl.rcParams['savefig.directory'] = os.getcwd()
import numpy as np

csv1 = sys.argv[1]
csv2 = sys.argv[2]

data1 = np.loadtxt(csv1,delimiter=';',skiprows=1)
data2 = np.loadtxt(csv2,delimiter=';',skiprows=1)
fig = plt.figure('Accelerance')
ax1 = fig.add_subplot(211)
ax2 = fig.add_subplot(212)
ax1.semilogy(2*np.pi*data1[:,0],data1[:,1],label=r'modal method $v_2$')
ax1.semilogy(2*np.pi*data2[:,0],data2[:,1],label=r'direct method $v_2$')
ax2.semilogy(2*np.pi*data1[:,0],data1[:,2],c='g',label=r'modal method $v_4$')
ax2.semilogy(2*np.pi*data2[:,0],data2[:,2],c='g',label=r'direct method $v_4$')
ax1.grid()
ax2.grid()
ax1.set_xlabel(r'Frequency $\Omega$ [rad/s]')
ax2.set_xlabel(r'Frequency $\Omega$ [rad/s]')
ax1.set_ylabel(r'Accelerance [m/s$^2$/N]')
ax2.set_ylabel(r'Accelerance [m/s$^2$/N]')
ax1.legend(shadow=True)
ax2.legend(shadow=True)
ax1.set_yticks(np.array([1.e-2,1.e-1,1.e+0,1.e+1,1.e+2,1.e+3]))
ax2.set_yticks(np.array([1.e-2,1.e-1,1.e+0,1.e+1,1.e+2,1.e+3]))
ax1.set_ylim(1.e-2,1.e3)
ax2.set_ylim(1.e-2,1.e3)
plt.tight_layout()
plt.show()
