import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
df1 = pd.read_csv('hbm_xy_resp.csv',delimiter=';')
df2 = pd.read_csv('displacement_u101.csv',delimiter=';')
df3 = pd.read_csv('velocity_v101.csv',delimiter=';')

#fig1 = plt.figure('HBM',figsize=(8,6))
#ax1 = fig1.add_subplot(111)
fig2 = plt.figure('Phase Diagram',figsize=(8,6))
ax2 = fig2.add_subplot(111)
#ax1.plot(2*np.pi*df1['Frequency'],df1['H1-N101,u'],label='H1')
ax2.plot(df2['N101,u'],df3['N101,u'],'-o',label='')
#ax1.grid()
ax2.grid()
#ax1.set_ylabel(r'Amplitude $H_1$')
ax2.set_ylim(-1.5,1.5)
ax2.set_xlabel(r'Displacement $u$')
ax2.set_ylabel(r'Velocity $\dot{u}$')
#ax1.legend(shadow=True).set_draggable(True)
#ax2.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
