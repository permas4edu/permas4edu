import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

csv = sys.argv[1]

fig = plt.figure('Frequency response',figsize=(12,6))
ax = fig.add_subplot(111)
df = pd.read_csv(csv,delimiter=';')
ax.plot(df['Frequency'],20*np.log10(df['N836,v']/1.e3),label='Response')
ax.set_xlabel('Frequency $f$ [Hz]')
ax.set_ylabel(r'$\| H\|$ (dB re. 1ms$^{-2}$N$^{-1}$)')
ax.grid()
ax.legend(shadow=True).set_draggable(True)
plt.tight_layout()
ax.set_xticks(np.linspace(250.,3000.,12))
plt.savefig('frf.png')
plt.show()

