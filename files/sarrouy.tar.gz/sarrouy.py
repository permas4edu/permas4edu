import os, sys
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import mplcursors

def f(x):
    return x

fig = plt.figure('Campbell diagram',figsize=(8,8))
ax = fig.add_subplot(111)
df = pd.read_csv('campbell_rsfrq.csv',delimiter=';')
ax.plot(df['Rot.Freq.'],df['Mode 1'],label='1B')
ax.plot(df['Rot.Freq.'],df['Mode 3'],label='1F')
ax.plot(df['Rot.Freq.'],df['Mode 5'],label='2B')
ax.plot(df['Rot.Freq.'],df['Mode 7'],label='2F')
ax.plot(df['Rot.Freq.'],df['Mode 9'],label='3B')
ax.plot(df['Rot.Freq.'],df['Mode 11'],label='3F')
ax.plot(df['Rot.Freq.'],f(df['Rot.Freq.']),c='k',alpha=0.5,label=r'$\omega=\Omega$')
ax.set_xlabel('Rotation speed $f$ [Hz]')
ax.set_ylabel('Eigenfrequencies [Hz]')
ax.set_xlim(0.,70.)
ax.set_ylim(0.,60.)
ax.set_xticks(np.linspace(0.,70.,8))
ax.set_yticks(np.linspace(0.,60.,7))
ax.legend(shadow=True).set_draggable(True)
ax.grid()
plt.tight_layout()
plt.show()

