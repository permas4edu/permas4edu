import numpy as np
import matplotlib.pyplot as plt

fig = plt.figure()
#ax = plt.axes(projection='3d')
ax = fig.add_subplot(111)
origin = 'lower'
ax.set_xlabel('x')
ax.set_ylabel('y')
#ax.set_zlabel('z');
def mode(x,y):
    return np.cos(nx*np.pi*x/Lx)*np.cos(ny*np.pi*y/Ly) # *np.cos(nz*np.pi*z/Lz)

def f(nx,ny,nz):
    return 0.5*c*np.sqrt((nx/Lx)**2+(ny/Ly)**2+(nz/Lz)**2)

Lx = 8.
Ly = 4.
Lz = 2.
c = 343.2 # [m/s]
F = []
for nx in range(8):
    for ny in range(4):
        for nz in range(2):
            if (nx+ny+nz >0):
                F.append(f(nx,ny,nz))
F= np.sort(np.array(F))

ofile = open('rvaltab.res','a')
ofile.write('Analytical natural frequencies\n')
np.savetxt(ofile,np.c_[np.arange(1,len(F[:31])+1),F[:31]],fmt='%2i %.5e')
ofile.close()
x = np.linspace(0.,Lx,64)
y = np.linspace(0.,Ly,32)
z = np.linspace(0.,Lz,16)
X,Y = np.meshgrid(x,y)
nx = 1
ny = 1
nz = 0
Z = mode(X,Y)
#ax.contour3D(X, Y, Z, 50, cmap='binary')
ax.set_title(r'$f=%.3f [Hz],\quad n_x=%i,\quad n_y=%i,\quad n_z=%i$' %(f(nx,ny,nz),nx,ny,nz))
CS = ax.contourf(X, Y, Z, 10, cmap=plt.cm.coolwarm, origin=origin)
CS2 = ax.contour(CS, levels=CS.levels[::2], colors='r', origin=origin)
plt.savefig('modeshape')
