import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

csv = sys.argv[1]

fig = plt.figure('Natural frequencies',figsize=(12,6))
ax1 = fig.add_subplot(211)
ax2 = fig.add_subplot(212)
df = pd.read_csv(csv,delimiter=';')
ax1.semilogx(df['DV_1'],df['F_1'],label=r'$%s$' %df.keys()[1].replace('F','f'))
ax2.semilogx(df['DV_1'],df['F_2'],label=r'$%s$' %df.keys()[2].replace('F','f'))
ax1.set_xlabel('Spring stiffness $k$ [N/mm]')
ax2.set_xlabel('Spring stiffness $k$ [N/mm]')
ax1.set_ylabel(r'Natural frequency $f$ [Hz]')
ax2.set_ylabel(r'Natural frequency $f$ [Hz]')
ax1.grid()
ax2.grid()
ax1.legend(shadow=True).set_draggable(True)
ax2.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.savefig('mercier.png')
plt.show()
