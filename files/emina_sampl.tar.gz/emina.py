import os, sys
import pandas as pd
import numpy as np
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
E = 2.E11
A = 28.5E-4
I = 1940.E-8
L = 300.E-2
df1 = pd.read_csv('sampling_xdhis.csv',delimiter=';')
df2 = pd.read_csv('sampling_srhis.csv',delimiter=';')
C = L*df1['DV_1']/(E*I)
alpha = 1./(1+C)
fig = plt.figure('Buckling')
ax = fig.add_subplot(111)
ax.plot(alpha,df2['LSF_01'],label='$\lambda_1$')
ax.set_xlim(0.,1.)
ax.set_yticks(np.linspace(2.,12.,6))
ax.set_xlabel(r'$\alpha_{\varphi}=\frac{1}{1+\bar{C}_{\varphi}},\quad \bar{C}_{\varphi}=\frac{\ell}{E\,I} C_{\varphi} $')
ax.set_ylabel(r'$q_{cr}$ [N/m]')
ax.grid()
ax.legend(shadow=True).set_draggable(True)
plt.show()
