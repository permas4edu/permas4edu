import os, sys
import numpy as np
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('unbalance_whirl.csv',delimiter=';')
fig = plt.figure('Unbalance response',figsize=(10,6))
ax1 = fig.add_subplot(111)
#ax1 = fig.add_subplot(211)
#ax2 = fig.add_subplot(212,sharex=ax1)
ax1.semilogy(df['Frequency'],df['N6917,w'],label=df.keys()[2])
#ax2.semilogy(df['Frequency'],df['N6917,v'])
ax1.set_xlim(50.,300.)
ax1.set_yticks(np.array([1.E-8, 1.E-6, 1.E-4, 1.E-2]))
ax1.set_xlabel(r'Frequency $f$ [Hz]')
ax1.set_ylabel(r'Amplitude $w$ [m]')
ax1.legend(shadow=True).set_draggable(True)
#ax2.set_yticks(np.array([1.E-8, 1.E-6, 1.E-4, 1.E-2]))
plt.tight_layout()
plt.show()
