import os, sys
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy.interpolate import splev, splrep
import pandas as pd
import numpy as np
data = np.loadtxt('modes_mode.csv',delimiter=';',skiprows=1)
x = data[:,0]
fig=plt.figure('Mode shapes and its derivatives',figsize=(12,10))
ax1=fig.add_subplot(211)
ax2=fig.add_subplot(212,sharex=ax1)
ax1.plot(data[:,0],data[:,1],label='Mode 1')
ax1.plot(data[:,0],data[:,2],label='Mode 2')
ax1.plot(data[:,0],data[:,3],label='Mode 3')
xnew = np.linspace(x.min(),x.max(0),1000)
for i in range(1,4):
    tck = splrep(x   , data[:,i], s=3)
    ynew = splev(xnew     , tck, der=1)

    ax2.plot(xnew,ynew,label='Derivative Mode %i'%i)

ax1.legend(shadow=True).set_draggable(True)
ax2.legend(shadow=True).set_draggable(True)
ax1.grid()
ax2.grid()
ax1.set_xlabel(r'Position $x$ [mm]')
ax2.set_xlabel(r'Position $x$ [mm]')
plt.tight_layout()
plt.show()

