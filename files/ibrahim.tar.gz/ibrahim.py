import os, sys
import matplotlib as mpl
import matplotlib.pyplot as plt

import numpy as np
mpl.rcParams['savefig.directory'] = os.getcwd()

csv = sys.argv[1]
data = np.loadtxt(csv,delimiter=';',skiprows=1)

fig = plt.figure('Campbell diagram')
ax = fig.add_subplot(111)
ax.plot(60*data[:,0],data[:,1],label='BW-1')
ax.plot(60*data[:,0],data[:,3],label='FW-1')
ax.plot(60*data[:,0],data[:,5],label='BW-2')
ax.plot(60*data[:,0],data[:,7],label='FW-2')
ax.plot(60*data[:,0],data[:,0],'-.',c='k',alpha=.3)
ax.grid()
ax.set_xlabel('Rotational speed [rpm]')
ax.set_ylabel('Damped natural frequencies [Hz]')
#ax.set_yticks(np.linspace(0.,100.,11))
ax.legend(shadow=True).set_draggable(True)
ax.set_ylim(0.,100.)
ax.set_yticks(np.linspace(0.,100.,11))
plt.show()
