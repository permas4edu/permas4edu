import os, sys
import numpy as np
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
#mpl.use('Agg')
import matplotlib.pyplot as plt

import pandas
data=pandas.read_csv('step_0_tip.csv',delimiter=';')


fig = plt.figure('Tip deflection')
ax = fig.add_subplot(111)
ax.plot(data['Coor_X'],data['LPAT_1_w'],label=r'$w$')
ax.grid()
ax.set_xlabel(r'Position $x$ [m]')
ax.set_ylabel(r'Displacement $w$ [m]')
ax.legend(loc=0,shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
