import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
df0 = pd.read_csv('direct_frequency_xy_resp.csv',delimiter=';')
df1 = pd.read_csv('hbm_xy_resp.csv',delimiter=';')

fig = plt.figure('HBM',figsize=(12,8))
ax1 = fig.add_subplot(211)
ax2 = fig.add_subplot(212)
ax1.plot(2*np.pi*df0['Frequency'],df0['N101,u'],c='r',label=r'FRF 1st DOF')
ax1.plot(2*np.pi*df1['Frequency'],df1['H1-N101,u'],c='g',label=r'H1 1st DOF')
ax2.plot(2*np.pi*df0['Frequency'],df0['N102,u'],c='r',label=r'FRF 2nd DOF')
ax2.plot(2*np.pi*df1['Frequency'],df1['H1-N102,u'],c='g',label=r'H1 2nd DOF')
ax1.grid()
ax2.grid()
#ax1.set_xlim(0.0,10.0)
#ax2.set_xlim(0.0,10.0)
#ax1.set_ylim(0.0,11.0)
#ax2.set_ylim(0.0,8.0)
ax1.set_xticks(np.linspace(35.,70.0,8))
ax2.set_xticks(np.linspace(35.,70.0,8))
ax1.set_yticks(1.e-3*np.linspace(0.,5.0,6))
ax2.set_yticks(1.e-3*np.linspace(0.,10.0,6))
ax1.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
ax2.ticklabel_format(style='sci', axis='y', scilimits=(0,0))

ax1.set_ylabel(r'Response Amplitude $u_1$ [m]')
ax2.set_ylabel(r'Response Amplitude $u_2$ [m]')
ax1.set_xlabel(r'Excitation frequency $\Omega$ [rad/s]')
ax2.set_xlabel(r'Excitation frequency $\Omega$ [rad/s]')
ax1.legend(shadow=True).set_draggable(True)
ax2.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
