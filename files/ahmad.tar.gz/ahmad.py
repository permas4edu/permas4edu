import os, sys
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
fig = plt.figure('FRF')
ax = fig.add_subplot(111)
P_ref = 20.E-12
df = pd.read_csv('receiver_pres.csv',delimiter=';')
ax.plot(df['Frequency'],20*np.log10(df['N3752,P']/P_ref))
ax.set_xlabel('Frequency $f$ [Hz]')
ax.set_ylabel('SPL [dB]$; \quad P_{ref} = 20\mu$Pa')
ax.set_xticks(np.linspace(0.,1000.,11))
ax.grid()

plt.tight_layout()
plt.show()
