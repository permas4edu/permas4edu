import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
df = pd.read_csv('hbm_xy_resp.csv',delimiter=';')

fig = plt.figure('HBM',figsize=(8,12))
ax1 = fig.add_subplot(211)
ax2 = fig.add_subplot(212,sharex=ax1)
ax1.plot(2*np.pi*df['Frequency'],df['H1-N101,u'],c='r',label=r'H1 $x$')
ax2.plot(2*np.pi*df['Frequency'],df['H1-N102,u'],c='g',label=r'H1 $y$')
ax1.grid()
ax2.grid()
ax1.set_xlim(0.0,10.0)
ax2.set_xlim(0.0,10.0)
ax1.set_ylim(0.0,11.0)
ax2.set_ylim(0.0,8.0)
ax1.set_xticks(np.linspace(0.,10.0,11))
ax1.set_yticks(np.linspace(0.,10.0,6))
ax1.set_ylabel(r'Max. Amplitude $x$')
ax2.set_ylabel(r'Max. Amplitude $y$')
ax1.set_xlabel(r'Excitation frequency $\eta$')
ax2.set_xlabel(r'Excitation frequency $\eta$')
ax1.legend(shadow=True).set_draggable(True)
ax2.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
