import os, sys
import glob
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


fig = plt.figure('HBM',figsize=(8,12))
ax1 = fig.add_subplot(211)
ax2 = fig.add_subplot(212,sharex=ax1)
csvs = glob.glob('hbm_xy*.csv')
csvs.sort()
label=[0.01,0.02,0.05,0.1,0.2] # Load amplitudes
for i, csv in enumerate(csvs):
    df = pd.read_csv(csv,delimiter=';')
    ax1.plot(df['Frequency'],df['H1-N101,u'],label=r'$F=$%.2f [N]'%label[i])
    ax2.plot(df['Frequency'],df['H1-N102,u'],label=r'$F=$%.2f [N]'%label[i])
ax1.grid()
ax2.grid()
ax1.set_xlim(0.2,0.45)
ax2.set_xlim(0.2,0.45)
#ax1.set_ylim(0.0,0.6)
#ax2.set_ylim(0.0,8.0)
ax1.set_xticks(np.linspace(0.2,0.45,6))
ax1.set_yticks(np.linspace(0.0,3.5,8))
ax2.set_yticks(np.linspace(0.0,1.4,8))
ax1.set_ylabel(r'Max. Amplitude $x_1$')
ax2.set_ylabel(r'Max. Amplitude $x_2$')
ax1.set_xlabel(r'Excitation frequency $f$ [Hz]')
ax2.set_xlabel(r'Excitation frequency $f$ [Hz]')
ax1.legend(shadow=True).set_draggable(True)
ax2.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
