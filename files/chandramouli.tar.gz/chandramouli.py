import os, sys
import matplotlib as mpl
import matplotlib.pyplot as plt

import numpy as np
mpl.rcParams['savefig.directory'] = os.getcwd()

csv = sys.argv[1]
data = np.loadtxt(csv,delimiter=';',skiprows=1)

fig = plt.figure('Campbell diagram')
ax = fig.add_subplot(111)
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,1],label='BW-1')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,3],label='FW-1')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,5],label='BW-2')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,7],label='FW-2')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,9],label='BW-3')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,11],label='FW-3')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,13],label='BW-4')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,15],label='FW-4')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,17],label='BW-5')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,19],label='FW-5')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,21],label='BW-6')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,23],label='FW-6')
ax.plot(2*np.pi*data[:,0],2*np.pi*data[:,0],'-.',c='k',alpha=.3)
ax.grid()
ax.set_xlabel('Rotational speed [rad/s]')
ax.set_ylabel('Damped natural frequencies [rad/s]')
ax.set_yticks(np.linspace(0.,5000.,11))
ax.legend(shadow=True).set_draggable(True)
plt.show()
