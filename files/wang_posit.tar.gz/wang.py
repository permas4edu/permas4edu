import os, sys
import pandas as pd
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
mpl.rcParams['savefig.directory'] = os.getcwd()

import matplotlib.pyplot as plt

csv1 = sys.argv[1]
csv2 = sys.argv[2]

df1 = pd.read_csv(csv1,delimiter=';')
df2 = pd.read_csv(csv2,delimiter=';')

L = 305.0 # plate length

fig1 = plt.figure('Optimization')
ax1 = fig1.add_subplot(211)
ax2 = fig1.add_subplot(212,sharex=ax1)
ax1.plot(df1['Loop Number'],df1['FREQ1-1'])
ax2.plot(df2['Loop Number'],np.sin(np.deg2rad(45))*df2['DV-1']/L,c='g')
ax1.grid('on')
ax2.grid('on')
ax1.set_xlabel(r'Iteration $i$')
ax1.set_ylabel(r'Frequency $f_1$ [Hz]')
ax2.set_xlabel(r'Iteration $i$')
ax2.set_ylabel(r'$\frac{a}{L}$')
plt.tight_layout()
plt.savefig('wang',dpi=80)
#plt.show()
