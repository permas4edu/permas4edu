import os, sys
import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

df1 = pd.read_csv('tip_modal_tip.csv',delimiter=';')
df2 = pd.read_csv('tip_direct_tip.csv',delimiter=';')


fig = plt.figure('Frequency Response')
ax = fig.add_subplot(111)
ax.loglog(df1['Frequency'],df1['N728,v'],label='modal')
ax.loglog(df2['Frequency'],df2['N728,v'],label='direct')
ax.grid()
ax.set_xlabel('Frequency $f$ [Hz]')
ax.set_ylabel('Amplitude')
ax.legend(shadow=True).set_draggable(True)
plt.show()
