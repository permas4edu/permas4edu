import numpy as np
from scipy.io import loadmat
from scipy.sparse.linalg import eigs
from scipy.linalg import eig, eigh, cho_solve, cho_factor
A = loadmat('K.mat')
B = loadmat('M.mat')
C = loadmat('modes.mat')
#D = loadmat('rbm_modes.mat')
K = A['K'] # stiffness matrix
M = B['M'] # mass matrix
X = C['X'] # elastic modes
#RBM = D['XRIG'] # rigid body modes

w,v = eigh(K.todense(),M.todense()) 
f = np.sqrt(np.abs(w))/(2*np.pi)

# modal stiffness X.T K X
print (' ')
print ('Modal stiffness matrix')
print (' ')
print ('diag(',np.diag(np.dot(X.todense().T,np.dot(K.todense(),X.todense()))),')')
# modal mass X.T M X
print (' ')
print ('Modal mass matrix')
print (' ')
print ('diag(',np.diag(np.dot(X.todense().T,np.dot(M.todense(),X.todense()))),')')
print (' ')
print ('Natural frequencies f [Hz]')
print (' ')
print (f)
print (' ')
#print ('Check of rigid body modes')
#print (' ')
#print (np.dot(RBM.todense().T,np.dot(K.todense(),RBM.todense())))
#print (' ')
