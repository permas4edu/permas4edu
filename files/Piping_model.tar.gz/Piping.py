import os, sys, re
import gzip
from scipy.sparse import coo_matrix
from scipy.io import mmwrite, savemat
import matplotlib as mpl
mpl.use('Agg')
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pylab as plt
import matplotlib.cm as cm
import numpy as np
import warnings

inp = sys.argv[1]


if inp.endswith('gz'):
    ifile = gzip.open(inp,'r')
else:    
    ifile = open(inp,'r')
print
print ('Processing %s' %inp)
print
while 1:
    line = ifile.readline()
    if not line: break
    if re.search('\$DATAOBJECT',line):
        liste = line.split()
        matname = liste[4]
        print (matname)
        col = []
        row = []
        val = []
        while 1:
            line = ifile.readline()
            if not line: break
            if re.search('$EXIT COMPONENT',line): break
            if line.startswith('%!'):
                print
                print ('End of Data Object')
                print
                break
            if re.search('ROWDIM',line):
                liste = line.split()
                rowdim = int(liste[3])
                coldim = int(liste[6])
                print ('rowdim,coldim',rowdim, coldim)            
            if re.search('MATTYPE',line):
                liste = line.split()
                mattype = liste[6]
                if mattype == 'PS':
                    print ('Packed symmetric')
                elif mattype =='R':
                    print ('Rectangular')
                elif mattype =='D':
                    print ('Diagonal')
                else:
                    print ('Unknown matrix format')
                    
            if re.search('BLOCKFORM',line):
                if re.search('FORMAT = R',line):
                    typ = 'R'
                elif re.search('FORMAT = PS',line):
                    typ = 'PS'
            
            liste = line.split()
            if len(liste) == 3:
                row.append(int(liste[0])-1)
                col.append(int(liste[1])-1)
                val.append(float(liste[2].replace('D','E')))
#
#       fill lower triangular 
#
                if mattype == 'PS':
                    if col[-1] != row[-1]:
                        row.append(int(liste[1])-1)
                        col.append(int(liste[0])-1)
                        val.append(float(liste[2].replace('D','E')))          
            
            
        if matname =='BMLL':
            BMLL = coo_matrix((val,(row,col)),shape=(rowdim,coldim))
        elif matname =='BKLL':
            BKLL = coo_matrix((val,(row,col)),shape=(rowdim,coldim))                
        elif matname =='SRL':
            SRL = coo_matrix((val[1:],(row[1:],col[1:])),shape=(rowdim,coldim))
        elif matname =='XRIG':
            XRIG = coo_matrix((val[1:],(row[1:],col[1:])),shape=(rowdim,coldim))
        else:
            print ('Unknown matrix name %s' %matname)            

#
#   Matrix Market Format and Matlab
#
if inp == 'modes.mtl':  
    mmwrite('X',SRL)
    savemat('modes.mat',mdict={'X': SRL},format='5')
    try:
        mmwrite('XRIG',XRIG)
        savemat('rbm_modes.mat',mdict={'XRIG': XRIG},format='5')
    except:
        print ('No rigid body modes')
if inp == 'matrices.mtl':
    mmwrite('K',BKLL)
    savemat('K.mat',mdict={'K': BKLL},format='5')
    mmwrite('M',BMLL)
    savemat('M.mat',mdict={'M': BMLL},format='5')        
    fig1 = plt.figure('Matrices')
    ax1  = fig1.add_subplot(211)
    ax2  = fig1.add_subplot(212)
#   ax2.spy(BKLL)
    im1=ax1.imshow(BMLL.todense(),interpolation='none',cmap='coolwarm')
    ax1.set_title(r'Mass matrix $M$')
    im2=ax2.imshow(BKLL.todense(),interpolation='none',cmap='coolwarm')
    ax2.set_title(r'Stiffness matrix $K$')    
    plt.tight_layout()
    plt.savefig('matrices',dpi=100)
