import os
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
import mplcursors
df1 = pd.read_csv('uz_uz.csv',delimiter=';')
df2 = pd.read_csv('fz_fz.csv',delimiter=';')
fig = plt.figure('Force_displacement')
ax = fig.add_subplot(111)
plt.text(0.05,120,'Linear elasticity')
ax.plot(df1['N518,w'],df2['N518,Fw'],'-o',label='PERMAS')
ax.set_xlabel(r'Displacement of top surface [mm]')
ax.set_ylabel(r'Force on top surface [N]')
ax.grid()
ax.legend(shadow=True).set_draggable(True)
mplcursors.cursor(ax,multiple=True).connect(
    "add", lambda sel: sel.annotation.set_text(r'$F=%.5f [N]$'%df2['N518,Fw'][sel.index]))
plt.show()
