import os, sys
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

df1 = pd.read_csv('sampling_xdhis.csv',delimiter=';')
df2 = pd.read_csv('sampling_srhis.csv',delimiter=';')
fig = plt.figure('Natural frequencies')
ax1  = fig.add_subplot(211)
ax2  = fig.add_subplot(212,sharex=ax1)
ax1.set_title(r'$r = r_0+\Delta r; \quad r_0 = 10$ [mm]')
ax1.plot(df1['DV_5'],df2['F_1'],label=r'$f_1$')
ax1.plot(df1['DV_5'],df2['F_2'],label=r'$f_2$')
ax2.plot(df1['DV_5'],df2['F_3'],label=r'$f_3$')
ax2.plot(df1['DV_5'],df2['F_4'],label=r'$f_4$')
ax1.set_xlabel(r'Radius variation $\Delta r$ [mm]')
ax2.set_xlabel(r'Radius variation $\Delta r$ [mm]')
ax1.set_ylabel(r'$f_i$')
ax2.set_ylabel(r'$f_i$')
ax1.legend(shadow=True).set_draggable(True)
ax2.legend(shadow=True).set_draggable(True)
plt.tight_layout()
plt.show()
