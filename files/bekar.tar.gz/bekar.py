import pandas as pd
import numpy as np

def ini(x,y):
    return np.sin(np.pi*x/1000)*np.sin(np.pi*y/1000)

df = pd.read_csv('bekar_nodes.csv',delimiter=';')
     
nid = df['Label']
print (nid)
x = df[' "x"']
y = df[' "y"']
u0 = ini(x,y)
ofile = open('inival.dat','w')
np.savetxt(ofile,np.c_[nid,3*np.ones(x.size),u0],fmt='%8i %8i:%.8e') 
ofile.close()

