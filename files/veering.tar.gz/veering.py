import os
import numpy as np
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
xdhis = np.genfromtxt('sampling_xdhis.csv',delimiter=';',names=True)
srhis = np.genfromtxt('sampling_srhis.csv',delimiter=';',names=True)
header = srhis.dtype.names
fig = plt.figure('Mode Tracking')
ax = fig.add_subplot(111)
ax.set_title(r'$k_{23}=$%.1f [N/m]' %xdhis['DV_2'][0])
ax.plot(xdhis['DV_1'],srhis['F_1'],label=r'$%s$'%header[1].replace('F_1','f_2'))
ax.plot(xdhis['DV_1'],srhis['F_2'],label=r'$%s$'%header[2].replace('F_2','f_3'))
ax.legend(loc=0,shadow=True)
ax.grid()
ax.set_xlabel(r'Stiffness $k_{31}$ [N/m]')
ax.set_ylabel(r'Natural frequencies $f$ [rad/s]')
ax.set_ylim(48.,62.)
plt.show()
