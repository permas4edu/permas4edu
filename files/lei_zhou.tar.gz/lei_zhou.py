import os, sys
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
#mpl.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
csv1 = sys.argv[1]
csv2 = sys.argv[2]
fig = plt.figure('Transient response')
ax = fig.add_subplot(111)
df1 = pd.read_csv(csv1,delimiter=';')
df2 = pd.read_csv(csv2,delimiter=';')
ax.plot(df1['Time'],df1['N6051,v'],label='modal '+df1.keys()[1])
ax.plot(df2['Time'],df2['N6051,v'],'o',label='direct '+df2.keys()[1])
ax.grid()
ax.legend(shadow=True).set_draggable(True)
ax.set_xlabel('Time $t$ [s]')
ax.set_ylabel('Displacement response in $y$ direction [mm]')
plt.tight_layout()
plt.savefig('')
plt.show()


