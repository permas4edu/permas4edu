import os, sys
import re
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
#mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import AutoMinorLocator
minor_locator_x = AutoMinorLocator(6)
minor_locator_y = AutoMinorLocator(6)

res = sys.argv[1]

ifile = open(res,'r')
f = []
while 1:
    line = ifile.readline()
    if not line: break
    if re.search('RVALTAB.DISP',line):
        for i in range(3):
            line = ifile.readline()
        while 1:
            line = ifile.readline()
            if not line: break
            liste = line.split()
            if len(liste) != 4: break
            f.append(liste[1])
ifile.close()
n = len(f)
f = np.array(f).astype(float)
fig = plt.figure('Natural frequencies')
ax = fig.add_subplot(111)
ax.plot(np.arange(1,n+1),f,'-o',label='H6')

ax.set_ylim(0.,1600.)

ax.set_xlim(0.,51.0)
ax.set_ylim(0.,1600.)
ax.set_xlabel('Order')
ax.set_ylabel('Natural frequency $f$ [Hz]')
ax.legend(shadow=True).set_draggable(True)
#ax.grid(which='minor')
ax.xaxis.set_minor_locator(minor_locator_x)
ax.yaxis.set_minor_locator(minor_locator_y)
plt.grid(which='major',linestyle='-')
plt.grid(which='minor',linestyle='--')
plt.tight_layout()
plt.savefig('natural_frequencies')
plt.show()
