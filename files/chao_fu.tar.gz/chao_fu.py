import os, sys
import glob
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import mplcursors
colors = plt.rcParams["axes.prop_cycle"]()

fig = plt.figure('HBM',figsize=(12, 8))
ax = fig.add_subplot(111)
csvs = glob.glob('hbm_xy*.csv')
csvs.sort()
label=np.linspace(-1.,1.,21) # Load amplitudes
for i, csv in enumerate(csvs):
    print ('Processing %s'%csv)
    df = pd.read_csv(csv,delimiter=';')
    # Get the next color from the cycler
    c = next(colors)["color"]    
#    if i == 0:
    ax.semilogy(df['Frequency'],df['H1-N101,u'],color=c,label=r'$\xi=$%.1f'%label[i])
ax.grid()
ax.legend(shadow=True).set_draggable(True)
ax.set(xlabel=r'Frequency $f$ [Hz]', ylabel='Amplitude $x_1$ [m]')
ax.set_xlim(0.0,50.0)
ax.set_xticks(np.linspace(0.0,50.,11))
ax.set_yticks(np.array([1.E-7,1.E-6,1.E-5,1.E-4,1.E-3,1.E-2]))
mplcursors.cursor(ax,multiple=True)
plt.tight_layout()
plt.show()
