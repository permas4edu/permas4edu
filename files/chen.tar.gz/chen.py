import numpy as np
import pandas as pd
import glob
import os, sys
from scipy.linalg import lstsq
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt

fig = plt.figure('Sampling')
ax1 = fig.add_subplot(211)
ax2 = fig.add_subplot(212)
csv1s = glob.glob('sampling_*_xdhis.csv')
csv2s = glob.glob('sampling_*_srhis.csv')
csv1s.sort()
csv2s.sort()

def f(x,dv1,dv2):
    tmp = np.array([1,dv1,dv2,dv1**2,dv2**2])
    return np.dot(x,tmp)

for i in range(len(csv1s)):
    print ('Processing %s %s'%(csv1s[i],csv2s[i]))
    df1 = pd.read_csv(csv1s[i],delimiter=';')
    df2 = pd.read_csv(csv2s[i],delimiter=';')

#     print ('Means of natural frequencies')
#     print (df2['OMEGA_1'].mean())
#     print (df2['OMEGA_2'].mean())
#     print ('Variance of natural frequencies')
#     print (df2['OMEGA_1'].var())
#     print (df2['OMEGA_2'].var())
#
#     Response surface
#     y = a_0 + a_1 x_1 + a_2 x_2 + a_3 x_1^2 + a_4 x_2^2
#
    x1 = df1['DV_1']
    x2 = df1['DV_2']
    ax1.plot(x1,x2,'o',label='Design space %i'%(i+1))
    n = x1.shape[0]
    A = np.empty([n,5])
    A[:,0] = np.ones(n)
    A[:,1] = x1
    A[:,2] = x2
    A[:,3] = x1**2
    A[:,4] = x2**2
    b1 = df2['OMEGA_1']    
    b2 = df2['OMEGA_2']    
    y1,residues,rank,s = lstsq(A,b1)
    y2,residues,rank,s = lstsq(A,b2)
    ax2.plot(df2['OMEGA_1'],df2['OMEGA_2'],'o',label='Sampling %s'%(i+1))    
    if i == 0:
        dv1 = 1.05 
        dv2 = 0.93
        ax2.plot(f(y1,dv1,dv2),f(y2,dv1,dv2),'+',label='RSM1')
    elif i == 1:
        dv1 = 2.05
        dv2 = 1.93
        ax2.plot(f(y1,dv1,dv2),f(y2,dv1,dv2),'+',label='RSM2')
    else:
        pass


ax1.legend(shadow=True).set_draggable(True)
ax2.legend(shadow=True).set_draggable(True)

ax1.set_xlabel(r'$k_2$ [N/m]')
ax1.set_ylabel(r'$k_3$ [N/m]')
ax2.set_xlabel(r'$\omega_1$ [rad/s]')
ax2.set_ylabel(r'$\omega_2$ [rad/s]')
ax1.set_xlim(0.4,2.6)
ax1.set_ylim(0.4,2.6)
ax1.set_xticks(np.linspace(0.4,2.6,12))
ax1.set_yticks(np.linspace(0.4,2.6,12))
ax2.set_xlim(0.95,1.3)
ax2.set_ylim(1.4,2.8)
ax2.set_xticks(np.linspace(0.95,1.3,8))
ax2.set_yticks(np.linspace(1.4,2.8,8))
plt.tight_layout()
plt.show()
