import pandas as pd
import os, sys
import numpy as np
import matplotlib as mpl
mpl.rcParams['savefig.directory'] = os.getcwd()
import matplotlib.pyplot as plt

csv = sys.argv[1]

def w_approx(sol,r):
    return 0.25*r**2*(np.log(r)-1)*sol[0]+0.25*r**2*sol[1]+np.log(r)*sol[2]+sol[3]

df = pd.read_csv(csv,delimiter=';')
r = df['Coor_X']
w = df['LPAT_1_w']
A = np.array([[0.25*r_n**2*(np.log(r_n)-1),0.25*r_n**2,np.log(r_n),1] for r_n in r])
sol = np.linalg.lstsq(A,w,rcond=None)[0]
print (sol)
fig = plt.figure('Displacement')
ax = fig.add_subplot(111)
ax.plot(r,1.e3*w,label='PERMAS')
ax.plot(r,1.e3*w_approx(sol,r),'o',label='Least squares')
ax.legend(shadow=True).set_draggable(True)
ax.set_xlabel('Radius $r$ [m]')
ax.set_ylabel('Displacement $w$ [mm]')
ax.grid()
plt.tight_layout()
plt.show()
#print (A)
               
