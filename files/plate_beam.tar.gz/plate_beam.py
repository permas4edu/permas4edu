import os, sys
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

csv = sys.argv[1]

fig = plt.figure('Frequency Response')
ax = fig.add_subplot(111)
df = pd.read_csv(csv,delimiter=';')
ax.plot(df['Frequency'],df['N143,w'])
ax.set_xlabel('Frequency $f$ [Hz]')
ax.set_ylabel('Amplitude')
plt.tight_layout()
plt.show()
